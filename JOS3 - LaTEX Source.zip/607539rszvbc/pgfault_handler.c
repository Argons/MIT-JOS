void
page_fault_handler(struct Trapframe *tf)
{
	uint32_t fault_va;

	// Read processor's CR2 register to find 
    // the faulting address  
	fault_va = rcr2();

	// Handle kernel-mode page faults.
    
	// LAB 3: Your code here.

	if ((tf->tf_cs & 0x3) == 0)
		panic("page fault handler: in kernel mode\n");
	
	// LAB 4: Your code here.   
	
	if (curenv->env_pgfault_upcall != NULL) {
		struct UTrapframe *utf;

		if (UXSTACKTOP - PGSIZE <= tf->tf_esp &&
        	tf->tf_esp < UXSTACKTOP)
			utf = (struct UTrapframe *)(tf->tf_esp - 
            	  sizeof (struct UTrapframe) - 4);
		else
			utf = (struct UTrapframe *)(UXSTACKTOP -
            	  sizeof (struct UTrapframe));
		user_mem_assert(curenv, 
        				(void*) utf,
        				sizeof(struct UTrapframe), 
                        PTE_U | PTE_W);
		
		utf->utf_esp      = tf->tf_esp;
		utf->utf_eflags   = tf->tf_eflags;
		utf->utf_eip      = tf->tf_eip;
		utf->utf_regs     = tf->tf_regs;
		utf->utf_err      = tf->tf_err;
		utf->utf_fault_va = fault_va;

		curenv->env_tf.tf_eip = (uint32_t) 
        						curenv->env_pgfault_upcall;
		curenv->env_tf.tf_esp = (uint32_t) utf;
		env_run(curenv);
	 }
	
	// Destroy the environment that caused the fault.
	cprintf("[%08x] user fault va %08x ip %08x\n", 
    		curenv->env_id, fault_va, tf->tf_eip);
	print_trapframe(tf);
	env_destroy(curenv);
}