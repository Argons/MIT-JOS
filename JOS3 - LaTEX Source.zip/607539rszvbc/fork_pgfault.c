static void
pgfault(struct UTrapframe *utf)
{
	void *addr = (void *) utf->utf_fault_va;
	uint32_t err = utf->utf_err;
	int r;

	// LAB 4: Your code here.

	if (!(err & FEC_WR))
		panic("Page fault: not a write access.");  
	
	if (!(vpt[VPN(addr)] & PTE_COW))  
		panic("Page fualt: not a COW page.");  
	
	if ((r = sys_page_alloc(0, PFTEMP,
    						PTE_U|PTE_W|PTE_P)) < 0)
		panic("Page fault: sys_page_alloc err %e.", r);	
        
	memmove(PFTEMP, (void *)PTE_ADDR(addr), PGSIZE);  
	
	
	if ((r = sys_page_map(0, PFTEMP, 0, 
    					  (void *)PTE_ADDR(addr), 
                          PTE_U|PTE_W|PTE_P)) < 0)
		panic("Page fault: sys_page_map err %e.", r);  
	if ((r = sys_page_unmap(0, PFTEMP)) < 0)  
		panic("Page fault: sys_page_unmap err %e.", r);
}