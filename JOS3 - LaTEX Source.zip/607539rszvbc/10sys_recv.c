static int
sys_ipc_recv(void *dstva)
{
	// LAB 4: Your code here.

	if (dstva < (void *) UTOP && 
    	ROUNDDOWN(dstva, PGSIZE) != dstva)
    	return -E_INVAL;

    curenv->env_ipc_dstva = dstva;
	curenv->env_ipc_recving = 1;
	curenv->env_ipc_from = 0;
	curenv->env_status = ENV_NOT_RUNNABLE;
	sched_yield ();

	return 0;
}