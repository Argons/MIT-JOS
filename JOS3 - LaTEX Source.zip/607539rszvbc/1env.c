  // Should always have an idle process as first one.
  ENV_CREATE(user_idle);
  ENV_CREATE(user_yield);
  ENV_CREATE(user_yield);
  ENV_CREATE(user_yield);