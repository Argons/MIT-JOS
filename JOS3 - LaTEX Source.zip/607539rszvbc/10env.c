  // Lab 4 IPC
  // env is blocked receiving
  bool env_ipc_recving;  
  // va at which to map received page
  void *env_ipc_dstva;  
  // data value sent to us
  uint32_t env_ipc_value; 
  // envid of the sender
  envid_t env_ipc_from;	
  // perm of page mapping received
  int env_ipc_perm;	