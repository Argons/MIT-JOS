static void
trap_dispatch(struct Trapframe *tf)
{
	...
    
	// Handle clock and serial interrupts.
	// LAB 4: Your code here.

	if (tf->tf_trapno == IRQ_OFFSET + IRQ_TIMER)
		sched_yield ();

	// Unexpected trap: The user process or 
    // the kernel has a bug.
	print_trapframe(tf);
	if (tf->tf_cs == GD_KT)
		panic("unhandled trap in kernel");
	else {
		env_destroy(curenv);
		return;
	}
}