uint32_t
ipc_recv(envid_t *from_env_store, void *pg, int *perm_store)
{
	// LAB 4: Your code here.
	
	int r;
	if (pg != NULL)
	    r = sys_ipc_recv((void *) UTOP);
	else
	    r = sys_ipc_recv(pg);
	struct Env *curenv = (struct Env *) envs + 
    					 ENVX (sys_getenvid());
	if (from_env_store != NULL)
		*from_env_store = r < 0 ? 0 : curenv->env_ipc_from;
	if (perm_store != NULL)
		*perm_store = r < 0 ? 0 : curenv->env_ipc_perm;
	if (r < 0)
		return r;
	return curenv->env_ipc_value;
}

void
ipc_send(envid_t to_env, uint32_t val, void *pg, int perm)
{
	// LAB 4: Your code here.
    
	int r;	
	while ((r = sys_ipc_try_send(to_env, val, 
    	    pg != NULL ? pg : (void *) UTOP, perm)) < 0) 
	{
		if (r != -E_IPC_NOT_RECV)
			panic("ipc_send: send message error %e", r);
		sys_yield();
	}
}