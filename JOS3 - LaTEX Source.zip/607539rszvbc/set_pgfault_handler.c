void
set_pgfault_handler(void (*handler)(struct UTrapframe *utf))
{
	int r;

	if (_pgfault_handler == 0) {
		// First time through!
		
		// LAB 4: Your code here.

		if ((r = sys_page_alloc(0, 
        	(void*) (UXSTACKTOP - PGSIZE), 
        	PTE_U | PTE_P | PTE_W)) < 0)
			panic("set_pgfault_handler: %e", r);

		sys_env_set_pgfault_upcall(0, _pgfault_upcall);
	}

	// Save handler pointer for assembly to call.
	_pgfault_handler = handler;
}