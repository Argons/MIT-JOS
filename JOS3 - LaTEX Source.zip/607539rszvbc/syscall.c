static envid_t
sys_exofork(void)  
{
	envid_t ret;  
    struct Env *e;
    ret =  env_alloc(&e, curenv->env_id);  
    
	if (ret < 0)  
    	return ret; 
        
    e->env_status = ENV_NOT_RUNNABLE;
    
    // copy trap frame
    e->env_tf = curenv->env_tf;
    
    // make the child env return value zero
    e->env_tf.tf_regs.reg_eax = 0; 
    
    return e->env_id;  
}