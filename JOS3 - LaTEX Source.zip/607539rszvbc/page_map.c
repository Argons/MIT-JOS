static int
sys_page_map(envid_t srcenvid, void *srcva,
	     	 envid_t dstenvid, void *dstva, 
             int perm)
{
	if (srcva >= (void *)UTOP 			|| 
    	ROUNDUP(srcva, PGSIZE) != srcva || 
        dstva >= (void *)UTOP 			|| 
        ROUNDUP(dstva, PGSIZE) != dstva)
 		return -E_INVAL;

	if ((perm & PTE_U) == 0 || (perm & PTE_P) == 0)
 		return -E_INVAL;
        
 	if ((perm & ~PTE_USER) > 0)
 		return -E_INVAL;

 	struct Env *srcenv;
	if (envid2env(srcenvid, &srcenv, 1) < 0)
		return -E_BAD_ENV;

 	struct Env *dstenv;
 	if (envid2env(dstenvid, &dstenv, 1) < 0)
 		return -E_BAD_ENV;

	pte_t *pte;
	struct Page *p = page_lookup(srcenv->env_pgdir, 
    							 srcva, &pte);
	if (p == NULL || 
     	((perm & PTE_W) > 0 && 
         (*pte & PTE_W) == 0))
		return -E_INVAL;

	if (page_insert(dstenv->env_pgdir, p, dstva, perm) < 0)
		return -E_NO_MEM;
	return 0;
}