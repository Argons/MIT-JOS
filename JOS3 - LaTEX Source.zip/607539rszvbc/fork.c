envid_t
fork(void)
{
	// LAB 4: Your code here.
	envid_t envid;  
	uint8_t *addr;
	int r;  
	extern unsigned char end[];  
	set_pgfault_handler(pgfault);  
	envid = sys_exofork();  
	if (envid < 0)  
		panic("sys_exofork: %e", envid);  
	//child
    // can't set pgh here, must set before child running,
	// because when child runs, it will make a page fault.
	if (envid == 0) {  
		env = &envs[ENVX(sys_getenvid())];  
		return 0;  
	}  
	//parent  
	for (addr = (uint8_t*) UTEXT; addr < end; addr += PGSIZE)
		duppage(envid, VPN(addr));  
	duppage(envid, VPN(&addr));  
    
	//copy user exception stack  

	if ((r = sys_page_alloc(envid, 
    						(void *)(UXSTACKTOP - PGSIZE), 
                            PTE_P | PTE_U | PTE_W)) < 0)
		panic("sys_page_alloc: %e", r);  
	r = sys_env_set_pgfault_upcall(envid, 
    							   env->env_pgfault_upcall);  

	//set child status  

	if ((r = sys_env_set_status(envid, ENV_RUNNABLE)) < 0)  
		panic("sys_env_set_status: %e", r);  
	return envid;
}