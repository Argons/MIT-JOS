static int
sys_env_set_status(envid_t envid, int status) 
{
	struct Env *e;  
    if (status != ENV_RUNNABLE && 
    	status != ENV_NOT_RUNNABLE)  
    	return -E_INVAL;    
       
	if (envid2env(envid, &e, 1) < 0) 
        return -E_BAD_ENV;  
    e->env_status = status;  
    return 0;     
}