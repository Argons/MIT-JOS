static int
sys_page_unmap(envid_t envid, void *va)
{
	struct Env *e;  
	if (envid2env(envid, &e, 1) < 0)
    	return -E_BAD_ENV;  
    if ((uint32_t)va >= UTOP || PGOFF(va) != 0)  
		return -E_INVAL;  
    page_remove(e->env_pgdir, va);  
    return 0;
}