	extern void inter_irq_0();
	extern void inter_irq_1();
	extern void inter_irq_2();
	extern void inter_irq_3();
	extern void inter_irq_4();
	extern void inter_irq_5();
	extern void inter_irq_6();
	extern void inter_irq_7();
	extern void inter_irq_8();
	extern void inter_irq_9();
	extern void inter_irq_10();
	extern void inter_irq_11();
	extern void inter_irq_12();
	extern void inter_irq_13();
	extern void inter_irq_14();
	extern void inter_irq_15();
    
    SETGATE(idt[IRQ_OFFSET+0], 0, GD_KT, inter_irq_0, 0);
	SETGATE(idt[IRQ_OFFSET+1], 0, GD_KT, inter_irq_1, 0);
	SETGATE(idt[IRQ_OFFSET+2], 0, GD_KT, inter_irq_2, 0);
	SETGATE(idt[IRQ_OFFSET+3], 0, GD_KT, inter_irq_3, 0);
	SETGATE(idt[IRQ_OFFSET+4], 0, GD_KT, inter_irq_4, 0);
	SETGATE(idt[IRQ_OFFSET+5], 0, GD_KT, inter_irq_5, 0);
	SETGATE(idt[IRQ_OFFSET+6], 0, GD_KT, inter_irq_6, 0);
	SETGATE(idt[IRQ_OFFSET+7], 0, GD_KT, inter_irq_7, 0);
	SETGATE(idt[IRQ_OFFSET+8], 0, GD_KT, inter_irq_8, 0);
	SETGATE(idt[IRQ_OFFSET+9], 0, GD_KT, inter_irq_9, 0);
	SETGATE(idt[IRQ_OFFSET+10],0, GD_KT, inter_irq_10,0);
	SETGATE(idt[IRQ_OFFSET+11],0, GD_KT, inter_irq_11,0);
	SETGATE(idt[IRQ_OFFSET+12],0, GD_KT, inter_irq_12,0);
	SETGATE(idt[IRQ_OFFSET+13],0, GD_KT, inter_irq_13,0);
	SETGATE(idt[IRQ_OFFSET+14],0, GD_KT, inter_irq_14,0);
	SETGATE(idt[IRQ_OFFSET+15],0, GD_KT, inter_irq_15,0);
    
    // Setup a TSS so that we get the right stack
	// when we trap to the kernel.
	ts.ts_esp0 = KSTACKTOP;
	ts.ts_ss0  = GD_KD;
