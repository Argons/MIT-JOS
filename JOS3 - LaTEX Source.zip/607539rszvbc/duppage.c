static int
duppage(envid_t envid, unsigned pn)
{
	int r;
	void *addr;
	pte_t pte;

	// LAB 4: Your code here.
	addr = (void *) ((uint32_t) pn * PGSIZE);
	pte = vpt[VPN(addr)];
	if ((pte & PTE_W) > 0 || (pte & PTE_COW) > 0) {
		if ((r = sys_page_map(0, addr, envid, addr,
        					  PTE_U | PTE_P | PTE_COW)) < 0)
			panic("duppage: page re-mapping failed at 1 :\
            	  %e", r);
	
		if ((r = sys_page_map(0, addr, 0, addr, 
        					  PTE_U | PTE_P | PTE_COW)) < 0)
			panic("duppage: page re-mapping failed at 2 :\
            	  %e", r);
	} else {
		if ((r = sys_page_map(0, addr, envid, addr, 
        				      PTE_U | PTE_P)) < 0)
			panic("duppage: page re-mapping failed at 3 :\
            	  %e", r);
	}	
	return 0;
}