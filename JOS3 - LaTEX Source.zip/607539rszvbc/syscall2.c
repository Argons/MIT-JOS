static int
sys_page_alloc(envid_t envid, void *va, int perm)
{
    struct Env *e;  
    struct Page *page;     
	if ((uint32_t)va >= UTOP || 
    	PGOFF(va) != 0 	     || 
        (perm & 5) != 5 	 || 
        (perm & (~PTE_USER)) != 0 )  
		return -E_INVAL;
    // PTE_USER = PTE_U | PTE_P | PTE_W | PTE_AVAIL

   	if (envid2env(envid, &e, 1) < 0)
    	return -E_BAD_ENV;  
    if (page_alloc(&page) < 0)
        return -E_NO_MEM;  
    if (page_insert(e->env_pgdir, page, va, perm) < 0) {
        page_free(page);  
        return -E_NO_MEM;  
    }  
    //fill the new page with 0  
    memset(page2kva(page), 0, PGSIZE);  
	return 0;
}