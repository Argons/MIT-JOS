static int
sys_ipc_try_send(envid_t envid, uint32_t value, 
				 void *srcva, unsigned perm)
{
	// LAB 4: Your code here.
	struct Env *dstenv;
	int r;
	
    // target env does not exist
	if ((r = envid2env (envid, &dstenv, 0)) < 0)
		return -E_BAD_ENV;
	
	// target env is not blocked or message has been sent
	if (dstenv->env_ipc_recving == 0 || 
    	dstenv->env_ipc_from != 0 )
		return -E_IPC_NOT_RECV;
	
	// srcva < UTOP but not page aligned
	if (srcva < (void *) UTOP && 
    	ROUNDDOWN(srcva, PGSIZE) != srcva)
		return -E_INVAL;
        
	if (srcva < (void *) UTOP) {
		// check permission
		if ((perm & PTE_U) == 0 || (perm & PTE_P) == 0)
			return -E_INVAL;
		// PTE_USER = PTE_U | PTE_P | PTE_W | PTE_AVAIL
		if ((perm & ~PTE_USER) > 0)
			return -E_INVAL;
	}
    
	pte_t *pte;
	struct Page *p;
    
	// the page is not mapped in current env
	if (srcva < (void *) UTOP && 
    	(p = page_lookup(curenv->env_pgdir, 
        srcva, &pte)) == NULL)
		return -E_INVAL;
        
	if (srcva < (void *) UTOP && 
    	(*pte & PTE_W) == 0 && (perm & PTE_W) > 0)
		return -E_INVAL;
        
	// will send a page
	if (srcva < (void *) UTOP && 
    	dstenv->env_ipc_dstva != 0) {
		if (page_insert(dstenv->env_pgdir, p, 
        				dstenv->env_ipc_dstva, 
                        perm) < 0)
			return -E_NO_MEM;
		dstenv->env_ipc_perm = perm;
	}
    
	dstenv->env_ipc_from = curenv->env_id;
	dstenv->env_ipc_value = value;
	dstenv->env_status = ENV_RUNNABLE;
	dstenv->env_ipc_recving = 0;
	dstenv->env_tf.tf_regs.reg_eax = 0;


	curenv->env_ipc_send_to = -1;
	curenv->env_ipc_send_succ++;
	dstenv->env_ipc_recv_min_send_succ = 0xffffffff;
	struct Env *envptr;
	for (envptr = envs+1; envptr < envs+NENV; envptr++)
		if (envptr->env_ipc_send_to == envid)
			if (envptr->env_ipc_send_succ < 
            	dstenv->env_ipc_recv_min_send_succ)
				dstenv->env_ipc_recv_min_send_succ = 
                envptr->env_ipc_send_succ;
	return 0;
}