envid_t dumbfork(void);
void
umain(void)
{
	envid_t who;
	int i;

	// fork a child process
	who = dumbfork();
    
	// print a message and yield to the other a few times
	for (i = 0; i < (who ? 10 : 20); i++) {
		cprintf("%d: I am the %s!\n", i, 
        		who ? "parent" : "child");
		sys_yield();
	}
}