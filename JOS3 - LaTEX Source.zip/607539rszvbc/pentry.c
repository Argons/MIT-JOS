.text
.globl _pgfault_upcall
_pgfault_upcall:
	// Call the C page fault handler.
	pushl %esp	    // function argument: pointer to UTF
	movl _pgfault_handler, %eax
	call *%eax
	addl $4, %esp	// pop function argument
	
	// LAB 4: Your code here.
	
	movl	0x30(%esp), %eax
	subl	$0x4, %eax
	movl	%eax, 0x30(%esp)
	movl	0x28(%esp), %ebx
	movl	%ebx, (%eax)

	// Restore the trap-time registers.
	// LAB 4: Your code here.

	addl	$0x8, %esp
	popal

	// Restore eflags from the stack.
	// LAB 4: Your code here.

	addl	$0x4, %esp
	popfl

	// Switch back to the adjusted trap-time stack.
	// LAB 4: Your code here.

	pop		%esp

	// Return to re-execute the instruction that faulted.
	// LAB 4: Your code here.
    
	ret