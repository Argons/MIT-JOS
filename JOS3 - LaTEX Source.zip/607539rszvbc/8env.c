  // Enable interrupts while in user mode.
  // LAB 4: Your code here.
  e->env_tf.tf_eflags |= FL_IF;