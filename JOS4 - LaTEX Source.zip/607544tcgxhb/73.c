void
serve_remove(envid_t envid, struct Fsreq_remove *rq)
{
	char path[MAXPATHLEN];
	int r;

	if (debug)
		cprintf("serve_remove %08x %s\n", envid, rq->req_path);

	// Copy in the path, making sure it's null-terminated
	memmove(path, rq->req_path, MAXPATHLEN);
	path[MAXPATHLEN-1] = 0;

	// Delete the specified file
	r = file_remove(path);
	ipc_send(envid, r, 0, 0);
}