void
write_block(uint32_t blockno)
{
	int r;
	char *addr;

	if (!block_is_mapped(blockno))
		panic("write unmapped block %08x", blockno);
	
	// Write the disk block and clear PTE_D.
	// LAB 5: Your code here.
	addr = diskaddr(blockno);

	if ((r = ide_write(blockno * BLKSECTS, 
    	addr, BLKSECTS)) < 0)
		panic("ide_write error: %e", r);

	if ((r = sys_page_map(0, addr, 0, addr, PTE_USER)) < 0)
		panic("sys_page_map error: %e", r);
}