// Read and validate the file system bitmap.
void
read_bitmap(void)
{
	int r;
	uint32_t i;
	char *blk;

	for (i = 0; i * BLKBITSIZE < super->s_nblocks; i++) {
		if ((r = read_block(2+i, &blk)) < 0)
			panic("cannot read bitmap block %d: %e", i, r);
		if (i == 0)
			bitmap = (uint32_t*) blk;
		// Make sure all bitmap blocks are marked in-use
		assert(!block_is_free(2+i));
	}
	
	// Make sure the reserved and root blocks 
    // are marked in-use.
	assert(!block_is_free(0));
	assert(!block_is_free(1));
	assert(bitmap);

	cprintf("read_bitmap is good\n");
}