void
serve_close(envid_t envid, struct Fsreq_close *rq)
{
	struct OpenFile *o;
	int r;

	if (debug)
		cprintf("serve_close %08x %08x\n", envid, 
        		rq->req_fileid);
	
	if ((r = openfile_lookup(envid, rq->req_fileid, &o)) < 0)
		goto out;
	file_close(o->o_file);
	r = 0;
	
  	out:
		ipc_send(envid, r, 0, 0);
}