void
serve_dirty(envid_t envid, struct Fsreq_dirty *rq)
{
	struct OpenFile *o;
	int r;

	if (debug)
		cprintf("serve_dirty %08x %08x %08x\n", envid, 
        		rq->req_fileid, rq->req_offset);

	// Find the file and dirty the file at the requested 
    // offset.
	// Send the return value back using ipc_send.
	// LAB 5: Your code here.
	if ((r = openfile_lookup(envid, rq->req_fileid, &o)) < 0)
		goto out;
	if ((r = file_dirty(o->o_file, rq->req_offset)) < 0)
		goto out;

  out:
      ipc_send(envid, 0, 0, 0);
}