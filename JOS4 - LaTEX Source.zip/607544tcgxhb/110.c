int
file_block_walk ( struct File *f, uint32_t filebno , 
uint32_t ** ppdiskbno , bool alloc)
{
    int r;
    uint32_t *ptr;
    char *blk;
    
    if ( filebno < NDIRECT )
    	ptr = &f-> f_direct [ filebno ];
    else
    {
      filebno =filebno - NDIRECT ;
      if ( filebno < NINDIRECT2 ) {
        if (f-> f_indirect == 0) {
            //1 st level indirect block not exists
            if ( alloc == 0)
                return -E_NOT_FOUND ;
            if ((r = alloc_block ()) < 0)
                return r;
            f-> f_indirect = r;
            // the 1st level indirect block
        }
        else
            alloc = 0;
        // we did not allocate a block
        if ((r = read_block (f->f_indirect , &blk)) < 0)
            return r;
        assert (blk != 0);
        if ( alloc )
            // must clear any block allocated
            memset (blk , 0, BLKSIZE );
        ptr = ( uint32_t *) blk + filebno /1024;
        // then we try to get 2nd level indirect block
        if (* ptr ==0)
        {
            if ((r = alloc_block ()) < 0)
                return r;
            *ptr=r;
            alloc =1;
        }
        else
            alloc =0;
        if ((r = read_block (*ptr , &blk)) < 0)
            return r;
        assert (blk !=0);
        if ( alloc )
            memset (blk ,0, BLKSIZE );
        ptr = ( uint32_t *) blk + filebno %1024;
      }
      
      else
      	return -E_INVAL ;
    }
    * ppdiskbno = ptr;
    return 0;
}