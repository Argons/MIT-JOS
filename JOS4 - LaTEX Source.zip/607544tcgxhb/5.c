int
alloc_block_num(void)
{
	// LAB 5: Your code here.
	if (super) {
		int i;

		for (i = 0; i < super->s_nblocks; i++) {
			if (block_is_free(i)) {
				bitmap[i/32] &= ~(1<<(i%32));
				// write back free block bitmap
				write_block(i/BLKBITSIZE+2);
				return i;
			}
		}
	}
	return -E_NO_DISK;
}