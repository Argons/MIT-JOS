int
file_get_block(struct File *f, uint32_t filebno, char **blk)
{
	int r;
	uint32_t diskbno;

	// Read in the block, leaving the pointer in *blk.
	// Hint: Use file_map_block and read_block.
	// LAB 5: Your code here.
	if ((r = file_map_block(f, filebno, &diskbno, 1)) < 0)
		return r;
	if ((r = read_block(diskbno, blk)) < 0)
		return r;
	return 0;
}
