/* Initialize the 8259A interrupt controllers. */
void
pic_init(void)
{
	...
	if (irq_mask_8259A != 0xFFFF)
    	irq_mask_8259A &= ~(1 << 14);
		irq_setmask_8259A(irq_mask_8259A);
}