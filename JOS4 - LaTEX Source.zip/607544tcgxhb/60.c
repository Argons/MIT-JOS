// Open "path". On success set *pf to point at the file 
// and return 0.
// On error return < 0.
int
file_open(const char *path, struct File **pf)
{
	int result = walk_path(path, 0, pf, 0);
    return result < 0 ? result : 0;
}