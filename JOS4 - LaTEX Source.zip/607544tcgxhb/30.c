static int
read_block(uint32_t blockno, char **blk)
{
	int r;
	char *addr;

	if (super && blockno >= super->s_nblocks)
		panic("reading non-existent block %08x\n", 
        blockno);

	if (bitmap && block_is_free(blockno))
		panic("reading free block %08x\n", 
        blockno);

	// LAB 5: Your code here.
	if ((r = map_block(blockno)) < 0)
		return r;

	addr = diskaddr(blockno);
	if ((r = ide_read(blockno * BLKSECTS,
    addr, BLKSECTS)) < 0)
		return r;

	if (blk)
		*blk = addr;

	return 0;
}