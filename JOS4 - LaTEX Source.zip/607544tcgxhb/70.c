void
serve_map(envid_t envid, struct Fsreq_map *rq)
{
	int r;
	char *blk;
	struct OpenFile *o;
	int perm;

	if (debug)
		cprintf("serve_map %08x %08x %08x\n", 
        envid, rq->req_fileid, rq->req_offset);

	// Map the requested block in the client's address space
	// by using ipc_send.
	// Map read-only unless the file's open 
    // mode (o->o_mode) allows writes
	// (see the O_ flags in inc/lib.h).
	// LAB 5: Your code here.
	if ((r = openfile_lookup(envid, rq->req_fileid, &o)) < 0) {
		ipc_send(envid, r, 0, 0);
		return;
	}
	if ((r = file_get_block(o->o_file, 
    	rq->req_offset/BLKSIZE, &blk)) < 0) {
		ipc_send(envid, r, 0, 0);
		return;
	}

	perm = PTE_P | PTE_U | PTE_SHARE;
	if ((o->o_mode & O_WRONLY) ||
	    (o->o_mode & O_RDWR))
		perm |= PTE_W;

	ipc_send(envid, 0, blk, perm);
}