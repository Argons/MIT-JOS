void
file_flush(struct File *f)
{
	int i;
	uint32_t diskbno;
	
	for (i = 0; i < (f->f_size + BLKSIZE - 1) / BLKSIZE; i++) {
		if (file_map_block(f, i, &diskbno, 0) < 0)
			continue;
		if (block_is_dirty(diskbno))
			write_block(diskbno);
	}	
}