int
env_alloc(struct Env **newenv_store, envid_t parent_id)
{
	...
	// If this is the file server (e == &envs[1]) 
    // give it I/O privileges.
	// LAB 5: Your code here.
	if (e == &envs[1])
		e->env_tf.tf_eflags |= FL_IOPL_3;
    ...
}