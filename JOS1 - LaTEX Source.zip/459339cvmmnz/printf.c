// (unsigned) octal
case 'o':
	num = getuint(&ap, lflag);
	base = 8;// octal flag
	goto number;

