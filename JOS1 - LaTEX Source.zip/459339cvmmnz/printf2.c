// (unsigned) octal
case 'o':
	// Replace this with your code.
	putch('X', putdat);
	putch('X', putdat);
	putch('X', putdat);
	break;
