int
mon_backtrace(int argc, char **argv, struct Trapframe *tf)
{
	// Your code here.
	uint32_t eip = eip;  
	uint32_t ebp = read_ebp();  
	cprintf("Stack backtrace:\n");
    
	uint32_t esp = ebp;  
	int j = 0;    
	while (ebp != 0) {  
            cprintf("ebp %08x eip %08x ", ebp, eip);  
            ebp = *(uint32_t *)(esp);  
            esp += 4; // read the next address 
            eip = *(uint32_t *)(esp);  
            esp += 4;
            
            cprintf("args "); // disply 5 arguments 
            for (j = 0; j < 5; j++) {  
                cprintf("%08x ", *(uint32_t *)(esp));  
                esp += 4;  
            }  
            cprintf("\n");  
            esp = ebp;  
	}
	return 0;
}

// defined in /lab1/inc/x86.h
static __inline uint32_t
read_ebp(void)
{
        uint32_t ebp;
        __asm __volatile("movl %%ebp,%0" : "=r" (ebp));
        return ebp;
}