.globl		_start
_start:
	movw	$0x1234,0x472			# warm boot

	# Establish our own GDT in place of the boot loaders temporary GDT.
	lgdt	RELOC(mygdtdesc)		# load descriptor table

#define	RELOC(x) ((x) - KERNBASE)

# setup the GDT	
	.p2align	2			# force 4 byte alignment
mygdt:
	SEG_NULL				# null seg
	SEG(STA_X|STA_R, -KERNBASE, 0xffffffff)		# code seg
	SEG(STA_W, -KERNBASE, 0xffffffff)			# data seg
mygdtdesc:
	.word	0x17			# sizeof(mygdt) - 1
	.long	RELOC(mygdt)	# address mygdt