void
env_create(uint8_t *binary, size_t size)
{
	// LAB 3: Your code here.
	struct Env *env;
	env_alloc(&env, 0);
	load_icode(env, binary, size);
	return;
}