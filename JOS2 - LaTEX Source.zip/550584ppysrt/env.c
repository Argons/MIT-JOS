void
env_init(void)
{
	// LAB 3: Your code here.
	LIST_INIT(&env_free_list);
	int i = NENV;
	while(i--) {
		envs[i].env_id = 0;
		envs[i].env_status = ENV_FREE;
		LIST_INSERT_HEAD(&env_free_list, 
        				 &envs[i], 
        				 env_link);	
	}
	return;
}