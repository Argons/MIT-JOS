void
idt_init(void)
{
	extern struct Segdesc gdt[];
	
	// LAB 3: Your code here.
	extern void routine_divide ();
	extern void routine_debug  ();
	extern void routine_nmi    ();
	extern void routine_brkpt  ();
	extern void routine_oflow  ();
	extern void routine_bound  ();
	extern void routine_illop  ();
	extern void routine_device ();
	extern void routine_dblflt ();
	extern void routine_tss    ();
	extern void routine_segnp  ();
	extern void routine_stack  ();
	extern void routine_gpflt  ();
	extern void routine_pgflt  ();
	extern void routine_fperr  ();
	extern void routine_align  ();
	extern void routine_mchk   ();
	extern void routine_simderr();
	extern void routine_syscall();

	SETGATE (idt[T_DIVIDE], 0, GD_KT, 
    routine_divide, 0);
    SETGATE (idt[T_DEBUG],  0, GD_KT, 
    routine_debug,  0);
    SETGATE (idt[T_NMI],    0, GD_KT, 
    routine_nmi,    0);
    
    // break point needs no kernel mode privilege
	SETGATE (idt[T_BRKPT], 0, GD_KT, 
    routine_brkpt, 3);

	SETGATE(idt[T_OFLOW], 0, GD_KT, 	
    		routine_oflow, 0);
	SETGATE(idt[T_BOUND], 0, GD_KT, 
    		routine_bound, 0);
	SETGATE(idt[T_ILLOP], 0, GD_KT, 
    		routine_illop, 0);
	SETGATE(idt[T_DEVICE], 0, GD_KT, 
    		routine_device, 0);
	SETGATE(idt[T_DBLFLT], 0, GD_KT, 
    		routine_dblflt, 0);
	SETGATE(idt[T_TSS], 0, GD_KT, 
    		routine_tss, 0);
	SETGATE(idt[T_SEGNP], 0, GD_KT, 
    		routine_segnp, 0);
	SETGATE(idt[T_STACK], 0, GD_KT, 
    		routine_stack, 0);
	SETGATE(idt[T_GPFLT], 0, GD_KT, 
    		routine_gpflt, 0);
	SETGATE(idt[T_PGFLT], 0, GD_KT, 
    		routine_pgflt, 0);
	SETGATE(idt[T_FPERR], 0, GD_KT, 
    		routine_fperr, 0);
	SETGATE(idt[T_ALIGN], 0, GD_KT, 
    		routine_align, 0);
	SETGATE(idt[T_MCHK], 0, GD_KT, 
    		routine_mchk, 0);
	SETGATE(idt[T_SIMDERR], 0, GD_KT, 
    		routine_simderr, 0);

	extern void routine_system_call();
	SETGATE(idt[T_SYSCALL], 0, GD_KT, 
    		routine_system_call, 3);

	// Setup a TSS so that we get the right stack
	// when we trap to the kernel.
	ts.ts_esp0 = KSTACKTOP;
	ts.ts_ss0 = GD_KD;

	// Initialize the TSS field of the gdt.
	gdt[GD_TSS >> 3] = SEG16(STS_T32A, 
    				   (uint32_t) (&ts), 
                       sizeof(struct Taskstate), 0);
	gdt[GD_TSS >> 3].sd_s = 0;

	// Load the TSS
	ltr(GD_TSS);

	// Load the IDT
	asm volatile("lidt idt_pd");
}