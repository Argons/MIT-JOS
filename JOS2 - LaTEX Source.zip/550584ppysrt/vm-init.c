void
i386_vm_init(void)
{
	...
   	size_t spages = ROUNDUP(npage * sizeof(struct Page), 
    					    PGSIZE);
	pages = (struct Page*) boot_alloc(spages, PGSIZE);
	physaddr_t ppages = PADDR(pages);
	boot_map_segment(pgdir, UPAGES, spages, ppages, PTE_U);

	// Make 'envs' point to an array of size 'NENV' of 
    // 'struct Env'.
	// Map this array read-only by the 
    // user at linear address UENVS
	// (ie. perm = PTE_U | PTE_P).
    
	// LAB 3: Your code here.
	envs = boot_alloc(NENV * sizeof(struct Env), PGSIZE);
	boot_map_segment(pgdir, 
    			     UENVS, 
                     ROUNDUP(NENV * sizeof(struct Env), 
                      	     PGSIZE), 
                     PADDR((uintptr_t) envs), 
                     PTE_U);
	...
}