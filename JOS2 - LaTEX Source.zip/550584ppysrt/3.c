  .c
  push values to make the stack look like a struct Trapframe
  load GD_KD into %ds and %es
  pushl %esp to pass a pointer to the Trapframe as an 
  argument to trap()
  call trap
  pop the values pushed in steps 1-3
  iret