/* The TRAPHANDLER macro defines a globally-
 * visible function for handling a trap. 
 * It pushes a trap number onto the stack, 
 * then jumps to _alltraps.
 * Use TRAPHANDLER for traps where the CPU  
 * automatically pushes an error code.
 */
 
#define TRAPHANDLER(name, num)
  // define global symbol for 'name'
  .globl name;
  // symbol type is function
  .type name, @function;
  // align function definition
  .align 2;	
  //function starts here
  name:	
  pushl $(num);
  jmp _alltraps

/* Use TRAPHANDLER_NOEC for traps where the 
 * CPU doesn't push an error code.
 * It pushes a 0 in place of the error code, 
 * so the trap frame has the same
 * format in either case.
 */
 
#define TRAPHANDLER_NOEC(name, num)
  .globl name;
  .type name, @function;
  .align 2;
  name:
  pushl $0;
  pushl $(num);
  jmp _alltraps