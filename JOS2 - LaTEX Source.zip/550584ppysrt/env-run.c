void
env_run(struct Env *e)
{
	// LAB 3: Your code here.
	curenv = e;
	curenv->env_runs++;
	lcr3(curenv->env_cr3);
	env_pop_tf(&(curenv -> env_tf));
}