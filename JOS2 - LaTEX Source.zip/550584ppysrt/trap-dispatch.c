static void
trap_dispatch(struct Trapframe *tf)
{
	// Handle processor exceptions.
	// LAB 3: Your code here.
	if (tf->tf_trapno == T_PGFLT)
		page_fault_handler (tf);
	if (tf->tf_trapno == T_BRKPT)
		monitor (tf);
	if (tf->tf_trapno == T_DEBUG)
		monitor (tf);
	int r;
	if (tf->tf_trapno == T_SYSCALL) {
		r = syscall(tf->tf_regs.reg_eax,
        			tf->tf_regs.reg_edx,
			   	    tf->tf_regs.reg_ecx,
                    tf->tf_regs.reg_ebx,
			    	tf->tf_regs.reg_edi,
                	tf->tf_regs.reg_esi);
		if (r < 0)
			panic("trap_dispatch:\
             	  The System Call number is invalid");

		tf->tf_regs.reg_eax = r;
		return;
	}
    
	// Unexpected trap: The user process or the kernel 
    // has a bug.
	print_trapframe(tf);
	if (tf->tf_cs == GD_KT)
		panic("unhandled trap in kernel");
	else {
		env_destroy(curenv);
		return;
	}
}