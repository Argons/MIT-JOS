static void
segment_alloc(struct Env *e, void *va, size_t len)
{
	// LAB 3: Your code here.
	// (But only if you need it for load_icode.)
	// 
	// 'va' and 'len' values that are not page-aligned.
	// You should round va down, and round len up.
	void* end = ROUNDUP((char*)va + len, PGSIZE);
	va = ROUNDDOWN(va, PGSIZE);
	if (va == NULL) 
    	va += PGSIZE;
	len = (char*)end - (char*)va;
	struct Page *pp;
	for (; len > 0; len -= PGSIZE, va += PGSIZE) {
	    int r;
        if ((r = page_alloc(&pp)) < 0) 
        	panic("segment_alloc: %e", r);
        if ((r = page_insert(e->env_pgdir, 
        				     pp, va, 
        				     PTE_W | PTE_U)) < 0) 
        	panic("segment_alloc: %e", r);
	}
}