void
i386_init(void)
{
	...   
	// Lab 3 user environment initialization functions
    env_init();
	idt_init();
    ...   
}

// user/evilhello.c:
void
umain(void)
{
	// try to print the kernel entry point as a string! 
    // mua ha ha!
	sys_cputs((char*)0xf010000c, 100);
}