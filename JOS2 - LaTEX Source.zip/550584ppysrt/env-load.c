static void
load_icode(struct Env *e, uint8_t *binary, size_t size)
{
  // LAB 3: Your code here.
  struct Elf *elf = (struct Elf *) binary;
  uint8_t* va = NULL;
  uint8_t* origin_va = NULL;
  int page_num = 0;
  int byte_num = 0;
  int copyed_byte = 0;
  int filesz = 0;
  int memsz = 0;
  int offset = 0;

  struct Proghdr *ph, *eph;
  int i,j;
  struct Page *p;
  pte_t* pte;

  if (elf->e_magic != ELF_MAGIC)
  	panic("elf->e_magic erro\n");
  // program header
  ph = (struct Proghdr *)(binary + elf->e_phoff);
  // one after last program header
  eph = ph + elf->e_phnum;
  // For each program header, load it into memory, 
  // zeroing as necessary
  for (; ph < eph; ph++) {
  	if (ph->p_type == ELF_PROG_LOAD) {
    // map segment
      segment_alloc(e, 
      				(uintptr_t *)(ph->p_va), 
      				ph->p_memsz);
      pte = (pte_t*)KADDR(
      		PTE_ADDR(e->env_pgdir[PDX(ph->p_va)]));
      origin_va = (uint8_t*)ROUNDDOWN(
      			  ph->p_va, PGSIZE);
      offset = ph->p_va - (int)origin_va;
      page_num = ROUNDUP(ph->p_filesz + offset, 
      					 PGSIZE) / PGSIZE;
      copyed_byte = 0;
      filesz = ph->p_filesz;
      for (j = 0; j < page_num; j++) {
        va = (uint8_t *)
        	 (KADDR(PTE_ADDR(
              pte[PTX(origin_va)])) + offset);
        origin_va += PGSIZE;
		if ((filesz + offset) > PGSIZE) {
          filesz -= PGSIZE - offset;
          byte_num = PGSIZE - offset;
        }
        else {
          byte_num = filesz;
        }

        offset = 0;
        memcpy(va, 
        	   binary + ph->p_offset + copyed_byte,
               byte_num);
        copyed_byte += byte_num;
      }
      
      if (copyed_byte != ph->p_filesz)
        panic("Load_icode failed\n");
    }
  }
  
  // Set up the environment's trapframe to 
  // point to the right location;
  // Other values for the trap frame as assigned 
  // in env_alloc
  
  e->env_tf.tf_eip = elf->e_entry;

  // Now map one page for the program's initial 
  // stack at virtual address USTACKTOP - PGSIZE.

  // LAB 3: Your code here.
  segment_alloc(e, 
  				(uintptr_t*)(USTACKTOP - PGSIZE),
  				PGSIZE);
}