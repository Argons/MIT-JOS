static int
env_setup_vm(struct Env *e)
{
	int i, r;
	struct Page *p = NULL;

	// Allocate a page for the page directory
	if ((r = page_alloc(&p)) < 0)
		return r;

	// Now, set e->env_pgdir and e->env_cr3,
	// and initialize the page directory.
	
	// LAB 3: Your code here.
	
	e->env_pgdir = page2kva(p);
	e->env_cr3 = page2pa(p);

	memmove(e->env_pgdir, boot_pgdir, PGSIZE);
 	memset (e->env_pgdir, 0, PDX(UTOP) * sizeof(pde_t));
	p->pp_ref++;
	// set the va above UTOP to be the same

	// VPT and UVPT map the env's own page table,
	// with different permissions.
	e->env_pgdir[PDX(VPT)]  = e->env_cr3 | PTE_P | PTE_W;
	e->env_pgdir[PDX(UVPT)] = e->env_cr3 | PTE_P | PTE_U;
	return 0;
}